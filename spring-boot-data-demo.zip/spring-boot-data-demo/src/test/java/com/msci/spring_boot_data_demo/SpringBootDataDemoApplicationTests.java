package com.msci.spring_boot_data_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
