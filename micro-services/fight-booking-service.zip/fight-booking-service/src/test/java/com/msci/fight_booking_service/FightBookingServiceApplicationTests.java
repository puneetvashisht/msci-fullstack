package com.msci.fight_booking_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FightBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
